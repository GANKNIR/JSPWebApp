/**
 * Spring JDBC extensions for managing incremental database migrations.
 */
package org.springframework.jdbc.versioned;

