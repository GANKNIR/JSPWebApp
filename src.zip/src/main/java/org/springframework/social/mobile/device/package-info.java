/**
 * Spring Mobile Device Extensions.
 */
package org.springframework.social.mobile.device;

