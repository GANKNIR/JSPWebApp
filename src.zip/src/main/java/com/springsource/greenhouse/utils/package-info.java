/**
 * Common utilities and helpers used by other packages.
 */
package com.springsource.greenhouse.utils;

