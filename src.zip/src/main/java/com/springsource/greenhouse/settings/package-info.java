/**
 * Supports changes and customizations to a member account.
 */
package com.springsource.greenhouse.settings;

