/**
 * Password reset behavior, for when you forget your password.
 */
package com.springsource.greenhouse.reset;

