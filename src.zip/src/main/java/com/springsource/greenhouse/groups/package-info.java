/**
 * Groups of members that work together or share common interests.
 */
package com.springsource.greenhouse.groups;

