/**
 * Allows groups of members to organize events of interest.  
 */
package com.springsource.greenhouse.events;

