/**
 * Domain package for member accounts modeling user identity.
 */
package com.springsource.greenhouse.account;

